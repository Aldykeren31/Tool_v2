"""
Modul Analisis Hasil / Pencocokan Data (CVE Matching)
=======================================================
Membandingkan versi RouterOS (dan port terbuka) yang berhasil
diidentifikasi pada fase enumeration dengan basis data referensi CVE
publik (data/cve_database.json), sesuai tahap "Analisis Hasil
(Pencocokan Data)" pada flowchart BAB III.

Skema atribut basis data mengikuti Tabel 3.2 Perancangan Basis Data:
cve_id, affected_version, severity_level, vulnerability_type,
description, mitigation_hint (plus beberapa atribut fungsional
tambahan: title, affected_component, affected_ports, version_type,
cvss, reference).

Field `affected_version` disimpan sebagai satu string agar sesuai
rancangan skema, namun tetap bisa dibandingkan secara terprogram lewat
mini-parser `parse_affected_version()` di bawah ini. Format yang
didukung per segmen (segmen dipisah `;` untuk beberapa cabang versi):

    "<= 6.49.7"                      -> dari versi 0 s.d. 6.49.7
    ">= 7.0"                         -> dari versi 7.0 s.d. tak terhingga
    "6.27 - 6.49.6"                  -> rentang eksplisit
    "stable: 6.27 - 6.49.6"          -> rentang dengan label cabang
    "stable: 6.27 - 6.49.6; long-term: <= 6.49.7"  -> gabungan beberapa cabang

Teks tambahan dalam tanda kurung, mis. "(RouterOS v7 tidak terdampak)",
diabaikan saat parsing (murni catatan untuk pembaca laporan).
"""

import json
import os
import re

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "cve_database.json")

INFINITY_TUPLE = (99999,)


def _version_tuple(v: str):
    """Ubah string versi menjadi tuple angka untuk dibandingkan.
    Versi non-numerik dikembalikan sebagai None.
    """
    if not v:
        return None
    match = re.match(r"^(\d+(?:\.\d+){0,3})", v.strip())
    if not match:
        return None
    return tuple(int(x) for x in match.group(1).split("."))


def parse_affected_version(affected_version: str) -> list:
    """Pecah string `affected_version` menjadi daftar rentang terstruktur:
    [{"branch": str, "from": str, "to": str|None}, ...]
    `to = None` berarti tidak terbatas ke atas (dari operator ">=").
    """
    if not affected_version:
        return []

    ranges = []
    for raw_segment in affected_version.split(";"):
        segment = raw_segment.strip()
        if not segment:
            continue

        # Buang catatan dalam tanda kurung, mis. "(cek changelog resmi ...)"
        segment = re.sub(r"\([^)]*\)", "", segment).strip()

        branch = "-"
        if ":" in segment:
            label, rest = segment.split(":", 1)
            branch = label.strip()
            segment = rest.strip()

        if segment.startswith("<="):
            ranges.append({"branch": branch, "from": "0", "to": segment[2:].strip()})
        elif segment.startswith(">="):
            ranges.append({"branch": branch, "from": segment[2:].strip(), "to": None})
        elif "-" in segment:
            parts = segment.split("-", 1)
            ranges.append({"branch": branch, "from": parts[0].strip(), "to": parts[1].strip()})
        else:
            # Versi tunggal (exact match)
            ranges.append({"branch": branch, "from": segment, "to": segment})

    return ranges


def _in_range(version_tuple, low: str, high) -> bool:
    low_t = _version_tuple(low) or (0,)
    high_t = INFINITY_TUPLE if high is None else _version_tuple(high)
    if high_t is None:
        # Batas atas tidak berformat versi baku -> jangan diloloskan otomatis
        return False
    length = max(len(version_tuple), len(low_t), len(high_t))
    v = version_tuple + (0,) * (length - len(version_tuple))
    lo = low_t + (0,) * (length - len(low_t))
    hi = high_t + (0,) * (length - len(high_t))
    return lo <= v <= hi


def load_database(path: str = DB_PATH) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def match(detected_version: str, open_ports: list, db: dict = None) -> list:
    """Cocokkan versi RouterOS yang terdeteksi & daftar port terbuka
    terhadap basis data CVE. Mengembalikan daftar CVE yang relevan,
    diurutkan dari severity tertinggi.
    """
    db = db or load_database()
    version_tuple = _version_tuple(detected_version)
    open_ports_set = set(open_ports)
    matches = []

    for cve in db.get("cves", []):
        reason = []
        matched = False

        # Kecocokan berdasar rentang versi (jika versi berhasil dibaca)
        if version_tuple and cve.get("version_type") == "routeros":
            for rng in parse_affected_version(cve.get("affected_version", "")):
                if _in_range(version_tuple, rng.get("from", "0"), rng.get("to")):
                    matched = True
                    branch_label = rng.get("branch", "-")
                    to_label = rng.get("to") if rng.get("to") is not None else "tak terbatas"
                    reason.append(
                        f"Versi terdeteksi {detected_version} berada dalam rentang terdampak "
                        f"({branch_label}: {rng.get('from')} - {to_label})"
                    )
                    break

        # Kecocokan tambahan berdasar port terbuka yang relevan dengan CVE,
        # ditandai sebagai indikasi (bukan kepastian) bila versi tak terbaca.
        cve_ports = set(cve.get("affected_ports", []))
        if cve_ports & open_ports_set:
            if not matched and not version_tuple:
                matched = True
                reason.append(
                    f"Port terkait layanan rentan terbuka ({sorted(cve_ports & open_ports_set)}), "
                    f"namun versi RouterOS tidak berhasil dipastikan -> perlu verifikasi manual."
                )
            elif matched:
                reason.append(f"Port layanan terkait juga ditemukan terbuka: {sorted(cve_ports & open_ports_set)}")

        if matched:
            entry = dict(cve)
            entry["match_reason"] = " ".join(reason)
            matches.append(entry)

    severity_order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
    matches.sort(key=lambda c: (severity_order.get(c.get("severity_level"), 9), -c.get("cvss", 0)))
    return matches
