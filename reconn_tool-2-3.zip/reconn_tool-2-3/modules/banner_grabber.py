"""
Modul Banner Grabbing & Service Enumeration (Fase 2: Enumeration)
===================================================================
Untuk setiap port yang terbukti terbuka, modul ini membangun koneksi
singkat guna menarik banner/response layanan dan, jika memungkinkan,
mengekstrak versi RouterOS yang berjalan pada target.

Teknik per-layanan:
- SSH (22)      : baca baris identifikasi protokol SSH yang otomatis
                  dikirim server saat handshake (mis. "SSH-2.0-ROSSSH").
- Telnet (23)   : baca banner awal yang biasanya memuat "RouterOS".
- HTTP/S (80/443): kirim GET, baca header Server & body login page.
- Winbox (8291) : baca beberapa byte awal (protokol biner MikroTik).
- API (8728/8729): baca respons awal handshake API.
"""

import re
import socket
import ssl

ROUTEROS_VERSION_RE = re.compile(r"(\d+\.\d+(?:\.\d+)?)")


def _recv_banner(sock: socket.socket, num_bytes: int = 256) -> bytes:
    try:
        return sock.recv(num_bytes)
    except Exception:
        return b""


def grab_ssh(ip: str, port: int = 22, timeout_s: float = 2.0) -> dict:
    info = {"port": port, "service": "SSH", "banner": "", "routeros_version": None}
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout_s)
            s.connect((ip, port))
            data = _recv_banner(s, 256).decode(errors="ignore").strip()
            info["banner"] = data
            if "ROSSSH" in data or "MikroTik" in data:
                info["routeros_version"] = "terindikasi RouterOS (ROSSSH)"
    except Exception as exc:
        info["error"] = str(exc)
    return info


def grab_telnet(ip: str, port: int = 23, timeout_s: float = 2.0) -> dict:
    info = {"port": port, "service": "Telnet", "banner": "", "routeros_version": None}
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout_s)
            s.connect((ip, port))
            data = _recv_banner(s, 512).decode(errors="ignore").strip()
            info["banner"] = data
            if "RouterOS" in data or "MikroTik" in data:
                match = ROUTEROS_VERSION_RE.search(data)
                info["routeros_version"] = match.group(1) if match else "terdeteksi (versi tidak terbaca)"
    except Exception as exc:
        info["error"] = str(exc)
    return info


def grab_http(ip: str, port: int = 80, use_ssl: bool = False, timeout_s: float = 2.5) -> dict:
    service_name = "Webfig (HTTPS)" if use_ssl else "Webfig (HTTP)"
    info = {"port": port, "service": service_name, "banner": "", "routeros_version": None, "server_header": None}
    try:
        raw_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        raw_sock.settimeout(timeout_s)
        raw_sock.connect((ip, port))
        if use_ssl:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            sock = ctx.wrap_socket(raw_sock)
        else:
            sock = raw_sock

        request = f"GET / HTTP/1.1\r\nHost: {ip}\r\nConnection: close\r\nUser-Agent: ReconTool/1.0\r\n\r\n"
        sock.sendall(request.encode())
        chunks = []
        try:
            while True:
                chunk = sock.recv(2048)
                if not chunk:
                    break
                chunks.append(chunk)
                if len(b"".join(chunks)) > 8192:
                    break
        except socket.timeout:
            pass
        finally:
            sock.close()

        raw = b"".join(chunks).decode(errors="ignore")
        info["banner"] = raw[:400]

        server_match = re.search(r"Server:\s*([^\r\n]+)", raw, re.IGNORECASE)
        if server_match:
            info["server_header"] = server_match.group(1).strip()

        if "MikroTik" in raw or "RouterOS" in raw or "webfig" in raw.lower():
            version_match = re.search(r"RouterOS\s*(?:v)?(\d+\.\d+(?:\.\d+)?)", raw, re.IGNORECASE)
            if not version_match:
                version_match = ROUTEROS_VERSION_RE.search(raw)
            info["routeros_version"] = version_match.group(1) if version_match else "terdeteksi (versi tidak terbaca)"
    except Exception as exc:
        info["error"] = str(exc)
    return info


def grab_winbox(ip: str, port: int = 8291, timeout_s: float = 2.0) -> dict:
    info = {"port": port, "service": "Winbox", "banner": "", "routeros_version": None}
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout_s)
            s.connect((ip, port))
            data = _recv_banner(s, 64)
            info["banner"] = data.hex()
            # Protokol Winbox bersifat biner tertutup; keberadaan respons
            # apapun pada port ini sudah menjadi indikator kuat perangkat
            # MikroTik (fingerprint berbasis port, bukan versi eksplisit).
            info["routeros_version"] = "port aktif (indikasi MikroTik, versi via Winbox tidak diekstrak)"
    except Exception as exc:
        info["error"] = str(exc)
    return info


def grab_api(ip: str, port: int = 8728, timeout_s: float = 2.0) -> dict:
    service_name = "API-SSL" if port == 8729 else "API"
    info = {"port": port, "service": service_name, "banner": "", "routeros_version": None}
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout_s)
            s.connect((ip, port))
            data = _recv_banner(s, 32)
            info["banner"] = data.hex()
            info["routeros_version"] = "port API aktif (indikasi MikroTik)"
    except Exception as exc:
        info["error"] = str(exc)
    return info


def grab_generic(ip: str, port: int, service: str, timeout_s: float = 1.5) -> dict:
    """Grabber generik untuk layanan yang tidak mengirim banner teks
    otomatis saat connect (mis. BGP, LDP, PPTP, uPnP, OpenFlow, DNS-TCP).
    Sekadar membuka koneksi & mencoba baca beberapa byte pasif -- kalau
    tidak ada apa-apa dalam batas waktu, itu normal untuk layanan ini
    (bukan berarti gagal), jadi cukup ditandai 'port aktif merespons'."""
    info = {"port": port, "service": service, "banner": "", "routeros_version": None}
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout_s)
            s.connect((ip, port))
            data = _recv_banner(s, 128)
            info["banner"] = data.hex() if data else "(tidak ada banner otomatis -- normal untuk layanan ini)"
    except Exception as exc:
        info["error"] = str(exc)
    return info


def grab_socks(ip: str, port: int = 1080, timeout_s: float = 2.0) -> dict:
    info = {"port": port, "service": "SOCKS proxy", "banner": "", "routeros_version": None}
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout_s)
            s.connect((ip, port))
            # Kirim SOCKS5 greeting: versi 5, 1 metode, "no auth"
            s.sendall(b"\x05\x01\x00")
            data = _recv_banner(s, 8)
            info["banner"] = data.hex()
            if data[:1] == b"\x05":
                info["routeros_version"] = "port aktif, merespons handshake SOCKS5 (indikasi MikroTik)"
    except Exception as exc:
        info["error"] = str(exc)
    return info


GRABBERS = {
    # --- profil "core" ---
    21: lambda ip, timeout_s=2.0: {"port": 21, "service": "FTP", "banner": "", "routeros_version": None},
    22: grab_ssh,
    23: grab_telnet,
    80: lambda ip, timeout_s=2.5: grab_http(ip, 80, use_ssl=False, timeout_s=timeout_s),
    443: lambda ip, timeout_s=2.5: grab_http(ip, 443, use_ssl=True, timeout_s=timeout_s),
    2000: lambda ip, timeout_s=1.5: grab_generic(ip, 2000, "Bandwidth Test", timeout_s),
    8291: grab_winbox,
    8728: lambda ip, timeout_s=2.0: grab_api(ip, 8728, timeout_s=timeout_s),
    8729: lambda ip, timeout_s=2.0: grab_api(ip, 8729, timeout_s=timeout_s),

    # --- profil "extended" ---
    20: lambda ip, timeout_s=1.5: grab_generic(ip, 20, "FTP data connection", timeout_s),
    53: lambda ip, timeout_s=1.5: grab_generic(ip, 53, "DNS (TCP)", timeout_s),
    179: lambda ip, timeout_s=1.5: grab_generic(ip, 179, "BGP", timeout_s),
    646: lambda ip, timeout_s=1.5: grab_generic(ip, 646, "LDP", timeout_s),
    1080: grab_socks,
    1723: lambda ip, timeout_s=1.5: grab_generic(ip, 1723, "PPTP", timeout_s),
    1966: lambda ip, timeout_s=1.5: grab_generic(ip, 1966, "MME gateway protocol", timeout_s),
    2828: lambda ip, timeout_s=1.5: grab_generic(ip, 2828, "uPnP", timeout_s),
    6343: lambda ip, timeout_s=1.5: grab_generic(ip, 6343, "OpenFlow", timeout_s),
    8080: lambda ip, timeout_s=2.5: grab_http(ip, 8080, use_ssl=False, timeout_s=timeout_s),
}


def grab_all(ip: str, open_ports: list, progress_cb=None) -> list:
    """Jalankan banner grabbing untuk seluruh port yang berstatus open."""
    results = []
    for port in open_ports:
        grabber = GRABBERS.get(port)
        if grabber:
            res = grabber(ip)
        else:
            res = {"port": port, "service": "Unknown", "banner": "", "routeros_version": None}
        results.append(res)
        if progress_cb:
            progress_cb(res)
    return results


def summarize_version(banner_results: list):
    """Ambil satu kandidat versi RouterOS paling meyakinkan dari seluruh
    hasil banner grabbing (mengutamakan hasil berformat angka versi)."""
    candidates = [r.get("routeros_version") for r in banner_results if r.get("routeros_version")]
    for c in candidates:
        if re.match(r"^\d+\.\d+", c or ""):
            return c
    return candidates[0] if candidates else None
