(() => {
  const targetInput = document.getElementById("target-input");
  const profileSelect = document.getElementById("profile-select");
  const scanBtn = document.getElementById("scan-btn");
  const scanError = document.getElementById("scan-error");
  const terminal = document.getElementById("terminal");
  const stagePill = document.getElementById("stage-pill");
  const pageTitle = document.getElementById("page-title");
  const pageSubtitle = document.getElementById("page-subtitle");
  const downloadBtn = document.getElementById("download-report");
  const topologyStatus = document.getElementById("topology-status");
  const targetNode = document.getElementById("target-node");
  const targetIpLabel = document.getElementById("target-ip-label");
  const link1 = document.getElementById("link-1");
  const link2 = document.getElementById("link-2");
  const pulse1 = document.getElementById("pulse-1");
  const pulse2 = document.getElementById("pulse-2");
  const portBadgesGroup = document.getElementById("port-badges");

  const stepperItems = Array.from(document.querySelectorAll("#stepper li"));
  const stageMap = {
    "Host Discovery (Cek Router Aktif)": "host",
    "Fase 1: Footprinting (Port Scanning)": "footprint",
    "Fase 2: Enumeration (Banner Grabbing)": "enum",
    "Analisis Hasil (Pencocokan Data CVE)": "analysis",
    "Output: Menyusun Laporan Otomatis": "report",
    "Selesai": "report",
  };

  let pollTimer = null;
  let lastLogCount = 0;
  let currentJobId = null;

  function setStage(stageKey, statusForStage) {
    stepperItems.forEach((li) => {
      const key = li.dataset.stage;
      li.classList.remove("active", "done", "error");
      const order = ["host", "footprint", "enum", "analysis", "report"];
      const curIdx = order.indexOf(stageKey);
      const thisIdx = order.indexOf(key);
      if (statusForStage === "failed" && thisIdx === curIdx) {
        li.classList.add("error");
      } else if (thisIdx < curIdx) {
        li.classList.add("done");
      } else if (thisIdx === curIdx) {
        li.classList.add("active");
      }
    });
  }

  function appendLogLines(logs) {
    if (logs.length === 0 && lastLogCount === 0) return;
    const placeholder = terminal.querySelector(".terminal-placeholder");
    if (placeholder) placeholder.remove();

    for (let i = lastLogCount; i < logs.length; i++) {
      const entry = logs[i];
      const line = document.createElement("div");
      line.className = "terminal-line";
      line.innerHTML = `<span class="t-time">[${entry.time}]</span>${escapeHtml(entry.message)}`;
      terminal.appendChild(line);
    }
    lastLogCount = logs.length;
    terminal.scrollTop = terminal.scrollHeight;
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function renderPorts(portScan) {
    const tbody = document.querySelector("#ports-table tbody");
    if (!portScan || portScan.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" class="empty-row">Belum ada data.</td></tr>`;
      return;
    }
    tbody.innerHTML = portScan.map((p) => {
      const isOpenish = p.status === "open" || p.status === "open|filtered";
      const label = p.status === "open" ? "OPEN" : p.status === "open|filtered" ? "OPEN|FILTERED" : "CLOSED";
      const cls = p.status === "open" ? "open" : p.status === "open|filtered" ? "filtered" : "closed";
      return `
      <tr>
        <td>${p.port}</td>
        <td>${(p.protocol || "tcp").toUpperCase()}</td>
        <td>${escapeHtml(p.service)}</td>
        <td><span class="status-chip ${cls}">${label}</span></td>
      </tr>
    `;
    }).join("");
  }

  function renderEnum(bannerGrab) {
    const el = document.getElementById("enum-list");
    if (!bannerGrab || bannerGrab.length === 0) {
      el.innerHTML = `<p class="empty-row">Belum ada data.</p>`;
      return;
    }
    el.innerHTML = bannerGrab.map((b) => `
      <div class="enum-card">
        <div class="enum-card-head">
          <span class="enum-card-title">${escapeHtml(b.service || "Unknown")}</span>
          <span class="enum-card-port">port ${b.port}</span>
        </div>
        ${b.banner ? `<div class="enum-card-banner">${escapeHtml(b.banner).slice(0, 300)}</div>` : ""}
        ${b.routeros_version ? `<div class="enum-card-version">&#9679; ${escapeHtml(b.routeros_version)}</div>` : ""}
        ${b.error ? `<div class="enum-card-version" style="color:var(--text-muted)">Gagal mengambil banner: ${escapeHtml(b.error)}</div>` : ""}
      </div>
    `).join("");
  }

  function renderCve(cveMatches) {
    const el = document.getElementById("cve-list");
    if (!cveMatches || cveMatches.length === 0) {
      el.innerHTML = `<p class="empty-row">Belum ada kecocokan CVE.</p>`;
      return;
    }
    el.innerHTML = cveMatches.map((c) => {
      const sev = (c.severity_level || "low").toLowerCase();
      return `
      <div class="cve-card sev-${sev}">
        <div class="cve-card-head">
          <span class="cve-id">${escapeHtml(c.cve_id)}</span>
          <span class="severity-badge ${sev}">${escapeHtml(c.severity_level || "-")}</span>
        </div>
        <p class="cve-title">${escapeHtml(c.title)}</p>
        ${c.vulnerability_type ? `<p class="cve-type">${escapeHtml(c.vulnerability_type)}</p>` : ""}
        <p class="cve-desc">${escapeHtml(c.description)}</p>
        ${c.mitigation_hint ? `<div class="cve-mitigation"><strong>Mitigasi:</strong> ${escapeHtml(c.mitigation_hint)}</div>` : ""}
        <p class="cve-reason">${escapeHtml(c.match_reason || "")}</p>
        <p class="cve-ref"><a href="${c.reference}" target="_blank" rel="noopener">Referensi &rarr;</a></p>
      </div>`;
    }).join("");
  }

  function updatePortBadges(portScan, targetIp) {
    portBadgesGroup.innerHTML = "";
    if (!portScan) return;
    const openPorts = portScan.filter((p) => p.status === "open");
    openPorts.slice(0, 6).forEach((p, i) => {
      const x = (i % 3) * 45 - 45;
      const y = Math.floor(i / 3) * 22;
      const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
      g.setAttribute("transform", `translate(${x},${y})`);
      g.innerHTML = `
        <rect class="port-badge-bg open" x="-19" y="-9" width="38" height="18" rx="9"></rect>
        <text class="port-badge-text open" y="4">${p.port}</text>
      `;
      portBadgesGroup.appendChild(g);
    });
  }

  function resetTopology() {
    link1.classList.remove("active");
    link2.classList.remove("active");
    pulse1.setAttribute("opacity", "0");
    pulse2.setAttribute("opacity", "0");
    targetNode.classList.remove("alive", "dead");
    portBadgesGroup.innerHTML = "";
    targetIpLabel.textContent = "\u2014";
    topologyStatus.textContent = "Standby";
    topologyStatus.classList.remove("live");
  }

  function activateTopology(job) {
    link1.classList.add("active");
    link2.classList.add("active");
    pulse1.setAttribute("opacity", job.status === "running" ? "1" : "0");
    pulse2.setAttribute("opacity", job.status === "running" ? "1" : "0");
    topologyStatus.textContent = job.status === "running" ? "Memindai\u2026" : (job.status === "done" ? "Selesai" : job.status);
    topologyStatus.classList.toggle("live", job.status === "running");

    const aliveHost = (job.host_discovery || []).find((h) => h.alive);
    if (aliveHost) {
      targetIpLabel.textContent = aliveHost.ip;
      targetNode.classList.add("alive");
    } else if (job.status === "inactive") {
      targetNode.classList.add("dead");
      targetIpLabel.textContent = "tidak aktif";
    }
  }

  function stagePillClass(status) {
    if (status === "running") return "running";
    if (status === "done") return "done";
    if (status === "failed" || status === "inactive") return "error";
    return "";
  }

  async function poll(jobId) {
    try {
      const res = await fetch(`/api/scan/${jobId}`);
      if (!res.ok) throw new Error("Job tidak ditemukan");
      const job = await res.json();

      appendLogLines(job.log || []);
      renderPorts(job.port_scan);
      renderEnum(job.banner_grab);
      renderCve(job.cve_matches);
      updatePortBadges(job.port_scan, job.target);
      activateTopology(job);

      stagePill.textContent = job.stage || job.status;
      stagePill.className = `stage-pill ${stagePillClass(job.status)}`;

      const stageKey = stageMap[job.stage] || "host";
      setStage(stageKey, job.status);

      pageTitle.textContent = `Target: ${job.target}`;
      if (job.status === "running") {
        pageSubtitle.textContent = job.stage;
      } else if (job.status === "inactive") {
        pageSubtitle.textContent = "Target tidak aktif / tidak merespons. Proses dihentikan sesuai flowchart.";
      } else if (job.status === "done") {
        pageSubtitle.textContent = `Reconnaissance selesai. ${(job.cve_matches || []).length} kerentanan relevan ditemukan.`;
      } else if (job.status === "failed") {
        pageSubtitle.textContent = `Terjadi kesalahan: ${job.error || "tidak diketahui"}`;
      }

      if (job.status === "done" && job.report_path) {
        downloadBtn.href = `/api/report/${jobId}`;
        downloadBtn.style.display = "inline-flex";
      }

      if (job.status === "running" || job.status === "queued") {
        pollTimer = setTimeout(() => poll(jobId), 900);
      } else {
        scanBtn.disabled = false;
        scanBtn.querySelector("span")?.remove();
      }
    } catch (err) {
      scanError.textContent = "Gagal memuat status scan.";
      scanBtn.disabled = false;
    }
  }

  async function startScan() {
    const target = targetInput.value.trim();
    const profile = profileSelect ? profileSelect.value : "core";
    scanError.textContent = "";
    if (!target) {
      scanError.textContent = "Isi target IP atau CIDR terlebih dahulu.";
      return;
    }

    scanBtn.disabled = true;
    lastLogCount = 0;
    terminal.innerHTML = `<div class="terminal-line terminal-placeholder">Menghubungkan ke target&hellip;</div>`;
    downloadBtn.style.display = "none";
    resetTopology();
    renderPorts([]);
    renderEnum([]);
    renderCve([]);
    pageTitle.textContent = `Target: ${target}`;
    pageSubtitle.textContent = "Memulai host discovery\u2026";

    if (pollTimer) clearTimeout(pollTimer);

    try {
      const res = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target, profile }),
      });
      const data = await res.json();
      if (!res.ok) {
        scanError.textContent = data.error || "Gagal memulai scan.";
        scanBtn.disabled = false;
        return;
      }
      currentJobId = data.job_id;
      poll(currentJobId);
    } catch (err) {
      scanError.textContent = "Tidak dapat terhubung ke server backend.";
      scanBtn.disabled = false;
    }
  }

  scanBtn.addEventListener("click", startScan);
  targetInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") startScan();
  });

  // Tabs
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`tab-${btn.dataset.tab}`).classList.add("active");
    });
  });
})();
