"""
Modul Port Scanner (Fase 1: Footprinting)
==========================================
Memindai port-port layanan manajemen bawaan MikroTik sesuai cakupan
skripsi: Winbox (8291), Webfig/HTTP (80), HTTPS (443), SSH (22),
Telnet (23), API (8728) dan API-SSL (8729).

Dua profil port didukung:
- "core"     : 9 port fokus utama penelitian (BAB III) -- default,
               perilaku sama seperti sebelumnya, tidak berubah.
- "extended" : menambahkan port TCP tambahan (FTP-data, DNS-TCP, BGP,
               LDP, SOCKS, PPTP, uPnP, OpenFlow, HTTP-proxy) untuk
               simulasi cakupan lebih luas di BAB IV. Port-port ini
               sama dengan yang disediakan scripts/dummy_mikrotik_target.py
               --profile extended, sehingga bisa dipakai berpasangan
               untuk pengujian dummy di dashboard ReconMTK.

Catatan: pemindaian tetap murni TCP connect scan (socket.connect_ex).
Port UDP dan nomor protokol IP (mis. /47 GRE, /89 OSPF) TIDAK dicakup
oleh scanner ini -- keduanya butuh teknik berbeda (raw socket/UDP scan)
dan didemonstrasikan terpisah lewat nmap, bukan lewat tool ini
(lihat catatan keterbatasan pada scripts/dummy_mikrotik_target.py).
"""

import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

# Port bawaan MikroTik yang menjadi fokus utama penelitian (BAB III)
MIKROTIK_PORTS = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    80: "Webfig (HTTP)",
    443: "Webfig (HTTPS)",
    2000: "Bandwidth Test",
    8291: "Winbox",
    8728: "API",
    8729: "API-SSL",
}

# Port TCP tambahan untuk profil "extended" (simulasi cakupan luas BAB IV)
EXTENDED_PORTS = {
    20: "FTP data connection",
    53: "DNS (TCP)",
    179: "Border Gateway Protocol (BGP)",
    646: "LDP transport session",
    1080: "SOCKS proxy protocol",
    1723: "Point-To-Point Tunneling Protocol (PPTP)",
    2828: "Universal Plug and Play (uPnP)",
    6343: "Default OpenFlow port",
    8080: "HTTP Web Proxy",
}


def get_port_set(profile: str = "core") -> dict:
    """Kembalikan dict {port: nama_layanan} sesuai profil yang dipilih."""
    if profile == "extended":
        merged = dict(MIKROTIK_PORTS)
        merged.update(EXTENDED_PORTS)
        return merged
    return dict(MIKROTIK_PORTS)


def scan_port(ip: str, port: int, timeout_s: float = 1.0, port_labels: dict = None) -> dict:
    """Lakukan TCP connect scan pada satu port."""
    port_labels = port_labels or MIKROTIK_PORTS
    started = time.time()
    status = "closed"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout_s)
            result = s.connect_ex((ip, port))
            status = "open" if result == 0 else "closed"
    except socket.gaierror:
        status = "error"
    except Exception:
        status = "error"
    return {
        "port": port,
        "service": port_labels.get(port, "Unknown"),
        "status": status,
        "latency_ms": round((time.time() - started) * 1000, 1),
    }


def scan_target(ip: str, ports=None, max_workers: int = 16, progress_cb=None, profile: str = "core") -> list:
    """Pindai seluruh port target pada satu IP secara paralel (threaded).

    `profile` menentukan set port default jika `ports` tidak diberikan
    secara eksplisit: "core" (9 port fokus, default) atau "extended"
    (core + port tambahan simulasi BAB IV).
    """
    port_labels = get_port_set(profile)
    ports = ports or list(port_labels.keys())
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(scan_port, ip, p, 1.0, port_labels): p for p in ports}
        for future in as_completed(futures):
            res = future.result()
            results.append(res)
            if progress_cb:
                progress_cb(res)
    results.sort(key=lambda r: r["port"])
    return results
